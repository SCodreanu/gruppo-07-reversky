- **P01 · Crea account** — ingresso predefinito. Breve presentazione di Reversky, form di registrazione, link **Accedi** e accesso alle pagine informative. La presentazione fa da mini landing.
- **P02 · Accedi** — form di login e accesso al recupero password.
- **P03 · Recupera password** — richiesta e impostazione della nuova password. Il link scaduto offre la possibilità di ricominciare.
- **Sessione scaduta** — rientro tramite **Accedi**, con ritorno alla destinazione quando è ancora accessibile.
Dopo la creazione account si arriva alla Home con il tour della mascotte. Dopo un accesso ordinario si arriva alla Home e il tour è richiamabile dalla guida.

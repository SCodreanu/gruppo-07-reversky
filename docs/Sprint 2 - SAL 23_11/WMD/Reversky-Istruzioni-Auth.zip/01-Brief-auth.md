# Reversky · Prime schermate di autenticazione
Proposta di lavoro per SWD e WMD. Prima PR consigliata: P02 Accedi, desktop e mobile.

## P02 · Accedi
Riusa la navigazione pubblica, il logo del gioco e i controlli del frontend. Ordine di lettura: titolo, email, password con mostra/nascondi, recupero password, azione Accedi, collegamento a Crea account. Il form deve funzionare con tastiera, Invio e gestore password. Mantieni le etichette visibili durante la digitazione.
Prova campo obbligatorio vuoto, credenziali errate, invio in corso, errore temporaneo e successo. Evita invii duplicati. Al successo apri la Home oppure la destinazione autorizzata interrotta da sessione scaduta.

## P03 · Recupera password
Percorso: richiesta via email → conferma generica → apertura del link → nuova password → conferma → Accedi. Per un link scaduto mostra Richiedi un nuovo link. Per la richiesta usa «Se esiste un account associato a questo indirizzo, riceverai un’email con le istruzioni».

## P01 · Crea account
SWD può preparare il modulo riutilizzando i controlli di P02. Usare i campi e i vincoli descritti sotto. WMD integra il modulo nella pagina pubblica con presentazione del gioco, artwork, link Accedi e accesso alle informazioni. Collegare il primo ingresso alla Home e al tutorial secondo sitemap.


## Contratto SWD verificato il 21 novembre 2026
Repository: https://github.com/SCodreanu/gruppo-07-reversky
Branch di riferimento API: backend_api, revisione 8f35d42. Documentazione allegata in 04-Contratto-SWD.md.
- P02: POST /api/v1/auth/login con email e password. 200 restituisce accessToken, refreshToken, tokenType, expiresIn. Gestire 400 dati non validi, 401 credenziali errate, 403 account disabilitato.
- P01: POST /api/v1/auth/register con username, email, password, acceptPrivacy e acceptTerms. Username ASCII alfanumerico o underscore, 3–30 caratteri. Email valida fino a 255 caratteri. Password 8–72 caratteri con almeno una lettera ASCII e una cifra. Entrambi i consensi obbligatori. 400 campi non validi, 409 conflitto, 201 senza corpo. Il 201 non apre una sessione: predisporre il passaggio ad Accedi o concordare un login successivo esplicito.
- P03: POST /api/v1/auth/password/forgot con email. Per una richiesta valida 204 anche quando l’indirizzo non è registrato. POST /api/v1/auth/password/reset con token e newPassword. 204 al successo, 400 AUTH_RESET_TOKEN_INVALID per link scaduto o non valido.
- Sono presenti rinnovo, logout, verifica email e reinvio. La sessione frontend deve utilizzare la rotazione del refresh token.
- WMD e SWD concordano destinazione del frontend, branch base, comando di avvio, origine di sviluppo e URL delle pagine aperte dai link email. Aggiungere collegamento ai frame Figma e variante approvata del logo dal main (docs/Materiali/Logo SVG).
- Prima PR consigliata: P02 Accedi con schermata desktop/mobile, esito positivo ed errori reali. Dichiarare quali verifiche sono state eseguite contro il servizio avviato.

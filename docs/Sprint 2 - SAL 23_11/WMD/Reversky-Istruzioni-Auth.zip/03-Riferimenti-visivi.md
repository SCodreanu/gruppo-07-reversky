**Palette riportata nei materiali Figma e nella proposta mockup**

| Token | Valore | Uso indicativo |
|---|---|---|
| Nero Notte | `#0F0E0D` | Sfondo |
| Osso | `#E9E4D8` | Testo principale |
| Rosso Reversky | `#981418` | Azioni principali e accenti |
| Cenere | `#8C867A` | Testo secondario e bordi con contrasto verificato |
| Ruggine Scura | `#5A0E12` | Superfici di enfasi |
| Bronzo Inchiostro | `#A67C3D` | Dettagli metallici |
| Pioggia Inversa | `#BFD4D6` | Accenti informativi |

- La proposta di mockup usa **IM FELL English SC** per i titoli, con H1/H2/H3 desktop 48/36/28 px, e **IBM Plex Mono** 16/14/12 px per testo, secondario ed etichette. Sansation e Sarabun compaiono nelle tavole di documentazione Figma. Verificare i token nativi prima di implementarli. Scala indicativa 4/8/12/16/24/32/48/64 px. Raggi 4 px per controlli, 8 px per pannelli e 12 px per modali. Bordo ordinario 1 px, indicatore di focus/selezione 2 px.
- Direzione UX per **Collezione** · carte verticali grandi e leggibili, griglia efficiente, dettaglio laterale persistente su desktop e accessibile da mobile. L’illustrazione originale va mostrata integralmente. Nella griglia bastano nome e quantità, con stato di selezione riconoscibile. Il dettaglio presenta rarità, Teoria, ATK/DEF ed effetti quando disponibili. «Aggiungi a un mazzo» apre la scelta del mazzo, con stato disattivato per una carta non posseduta.
